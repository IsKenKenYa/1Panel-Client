// B-S1 验证页：启动卡 S4（InitPiplineContext 后链断）
// 场景：模块顶层代码（abc 加载即执行，先于任何生命周期）阻塞 10 秒，
// 使流程停在 pipeline 初始化/前端初始化段——日志表现为
// InitPiplineContext（若已打印）之后长时间无 SetupRootElement/RunPage/F1/vsync。
// skill 维度①应判：链断点在 S4/S5 之间（启动段卡住），维度③ F1 未请求。
// 说明：top-level 阻塞在 abc 执行线程（JS 主线程），对应"pipeline 初始化线程被占"根因方向。

// 模块顶层：abc 加载时立即执行（EntryAbility import 本模块即触发）
const BS1_T1 = Date.now();
let BS1_X: number = 0;
while (Date.now() - BS1_T1 < 10000) {
  BS1_X += 1;
}
console.error('BS1: top-level block done, x=' + BS1_X);

@Entry
@Component
struct Index {
  build() {
    Column() {
      Text('B-S1: startup stall at S4 (top-level block 10s)')
        .fontSize(13)
    }
    .width('100%')
    .height('100%')
    .alignItems(HorizontalAlign.Center)
  }
}
