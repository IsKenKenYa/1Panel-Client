// B-S6 卡顿·时间戳大间隔验证页（v2：同步全量构建）
// List是懒加载只渲染可视区，无法制造构建压力。
// 改为 Scroll+ForEach 一次性同步构建 1200 个 Block（每个 27 节点 → 3万+节点），
// 使 SetupRootElement / RunPage / 首帧构建真实变慢，日志出现大间隔（超 25ms 基线）。

@Component
struct Row3 {
  build() {
    Row() {
      Text('A').fontSize(10)
      Text('B').fontSize(10)
      Text('C').fontSize(10)
    }
  }
}

@Component
struct Col9 {
  build() {
    Column() {
      Row3(); Row3(); Row3()
    }
  }
}

@Component
struct Block {
  build() {
    Column() {
      Col9(); Col9(); Col9()
    }
    .margin(1)
  }
}

@Entry
@Component
struct Index {
  private data: number[] = [];

  aboutToAppear() {
    // 1200 Block × 27节点 ≈ 3.2万节点，同步构建
    for (let i = 0; i < 1200; i++) {
      this.data.push(i);
    }
  }

  build() {
    Scroll() {
      Column() {
        Text('B-S6 v2: sync heavy build (1200 blocks)')
          .fontSize(12)
          .margin(8)
        ForEach(this.data, (item: number) => {
          Block()
        }, (item: number) => item.toString())
      }
    }
    .width('100%')
    .height('100%')
  }
}
