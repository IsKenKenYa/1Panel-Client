import router from '@ohos.router';

@Entry
@Component
struct Index {
  build() {
    Column() {
      Text('B-S5 验证工程')
        .fontSize(24)
        .fontWeight(FontWeight.Bold)
        .margin({ top: 60, bottom: 12 })
      Text('场景：aboutToAppear 抛 JS 异常（throw new Error）\n预期：框架 panda::TryCatch 捕获，不白屏不闪退；\nerrorManager 回调输出 JS 栈（BadPage.ets 行号）。\n点下方按钮进入 BadPage 触发。')
        .fontSize(13)
        .fontColor('#666')
        .margin({ left: 24, right: 24, bottom: 24 })
      Button('进入 BadPage（触发异常）')
        .width('80%')
        .onClick(() => {
          router.pushUrl({ url: 'pages/BadPage' });
        })
    }
    .width('100%')
    .height('100%')
    .alignItems(HorizontalAlign.Center)
  }
}
