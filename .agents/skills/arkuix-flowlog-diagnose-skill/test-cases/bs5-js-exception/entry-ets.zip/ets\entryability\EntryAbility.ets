import AbilityConstant from '@ohos.app.ability.AbilityConstant';
import UIAbility from '@ohos.app.ability.UIAbility';
import Want from '@ohos.app.ability.Want';
import window from '@ohos.window';
import errorManager from '@ohos.app.ability.errorManager';

export default class EntryAbility extends UIAbility {
  onCreate(want: Want, launchParam: AbilityConstant.LaunchParam) {
    console.error('HiHelloWorld: Ability onCreate');

    // 娉ㄥ唽鍏ㄥ眬JS寮傚父鍥炶皟锛氶獙璇佹敞鍐屽悗妗嗘灦鏄惁鎶婂紓甯告爤浼犵粰搴旂敤
    errorManager.on('error', {
      onUnhandledException: (errMsg: string) => {
        console.error('RealJSException [errorManager] caught error: ' + errMsg);
      }
    });
  }

  onDestroy() {
    console.error('HiHelloWorld: Ability onDestroy');
  }

  onWindowStageCreate(windowStage: window.WindowStage) {
    console.error('HiHelloWorld: Ability onWindowStageCreate');
    windowStage.loadContent('pages/Index', (err, data) => {
      if (err.code) {
        console.error('HiHelloWorld: Failed to load the content. Cause: ' + (JSON.stringify(err) ?? ''));
        return;
      }
      console.error('HiHelloWorld: Succeeded in loading the content.');
    });
  }

  onWindowStageDestroy() {
    console.error('HiHelloWorld: Ability onWindowStageDestroy');
  }

  onForeground() {
    console.error('HiHelloWorld: Ability onForeground');
  }

  onBackground() {
    console.error('HiHelloWorld: Ability onBackground');
  }
}
