@Entry
@Component
struct BadPage {
  @State result: string = 'loading...';
  test() {
    throw new Error('Cannot read property value of undefined at aboutToAppear (BadPage.ets:7)');
  }

  aboutToAppear() {
    console.error('RealJSException: BadPage aboutToAppear BEFORE throw');
    this.test();
    console.error('RealJSException: BadPage aboutToAppear AFTER throw (unreachable)');
  }

  build() {
    Column() {
      Text('如果你看到这段文字，说明异常未触发')
        .fontSize(20)
    }
    .width('100%')
    .height('100%')
    .alignItems(HorizontalAlign.Center)
  }
}
