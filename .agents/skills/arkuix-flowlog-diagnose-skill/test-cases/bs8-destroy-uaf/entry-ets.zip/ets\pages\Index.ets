// B-S8 验证页：销毁路径压力（屏障超时/UAF 风险场景）
// bench B-S8 期望：Destroy pipelineContext_ start 无 end（屏障未完成）→ UAF crash。
// 应用层构造方式：高频路由 push/back 反复创建/销毁页面 + onDisappear 慢任务，
// 增大销毁屏障超时与销毁竞态概率（真实 UAF 需框架并发缺陷配合，应用层只能造压力条件）。
// 验证方式：自动化反复 点击进入/返回，抓销毁段日志看 Destroy 链完整性。

import router from '@ohos.router';

@Entry
@Component
struct Index {
  @State cycles: number = 0;

  build() {
    Column() {
      Text('B-S8: destroy path stress')
        .fontSize(13)
        .margin({ top: 8 })
      Text('cycles: ' + this.cycles)
        .fontSize(12)
      Button('进 HeavyPage（onDisappear 慢）')
        .width('80%')
        .margin(8)
        .onClick(() => {
          this.cycles += 1;
          router.pushUrl({ url: 'pages/HeavyPage' });
        })
    }
    .width('100%')
    .height('100%')
    .alignItems(HorizontalAlign.Center)
  }
}
