import AbilityConstant from '@ohos.app.ability.AbilityConstant';
import UIAbility from '@ohos.app.ability.UIAbility';
import Want from '@ohos.app.ability.Want';
import window from '@ohos.window';

export default class EntryAbility extends UIAbility {
  onCreate(want: Want, launchParam: AbilityConstant.LaunchParam) {
    console.error('BS8: Ability onCreate');
  }

  onDestroy() {
    console.error('BS8: Ability onDestroy');
  }

  onWindowStageCreate(windowStage: window.WindowStage) {
    console.error('BS8: Ability onWindowStageCreate');
    windowStage.loadContent('pages/Index', (err, data) => {
      if (err.code) {
        console.error('BS8: Failed to load content: ' + (JSON.stringify(err) ?? ''));
        return;
      }
      console.error('BS8: Succeeded in loading content.');
    });
  }

  onWindowStageDestroy() {
    console.error('BS8: Ability onWindowStageDestroy');
  }

  onForeground() {
    console.error('BS8: Ability onForeground');
  }

  onBackground() {
    console.error('BS8: Ability onBackground');
  }
}
