// B-S8 HeavyPage：销毁路径带慢回调
import router from '@ohos.router';

@Entry
@Component
struct HeavyPage {
  aboutToDisappear() {
    console.error('BS8: HeavyPage aboutToDisappear start (slow)');
    // 销毁回调里的同步慢任务：增大销毁屏障超时/竞态概率
    const t1 = Date.now();
    let x: number = 0;
    while (Date.now() - t1 < 3000) {
      x += 1;
    }
    console.error('BS8: HeavyPage aboutToDisappear done');
  }

  build() {
    Column() {
      Text('HeavyPage（3s onDisappear）')
        .fontSize(13)
      Button('返回')
        .margin(16)
        .onClick(() => {
          router.back();
        })
    }
    .width('100%')
    .height('100%')
    .alignItems(HorizontalAlign.Center)
  }
}
