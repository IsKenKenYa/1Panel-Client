// B-S2 验证页 v2：首帧未上屏（F1 请求有、首帧 vsync 无）
// v1 教训：aboutToAppear 在 F1 之前执行，阻塞它会让 F1/vsync 一起延迟（成 B-S6 模式）。
// v2 方案：用 @State 标记 + onAppear（首帧上屏回调）区分：
//   build 首次执行时状态 done=false（首帧以占位渲染 → F1 发出）；
//   onAppear（首帧已上屏）后置 done=true 再触发第二阶段长任务验证渲染管线。
// 更直接方案：Text 的 onAppear 里阻塞 —— 此时 F1 已发出、vsync 已请求，
// 但若首帧依赖该组件完成，阻塞其 onAppear 造成 F1 与 vsync 之间出现"请求了未上屏"窗口。
// 实测采集窗口：F1(request first frame) 与 vsync(requests first Vsync) 时间差。

@Entry
@Component
struct Index {
  @State sum: number = 0;

  build() {
    Column() {
      Text('B-S2 v2: block between F1 and vsync')
        .fontSize(13)
        .onAppear(() => {
          console.error('BS2: onAppear fired (before/around first vsync), block 8s now');
          const t1 = Date.now();
          let x: number = 0;
          while (Date.now() - t1 < 8000) {
            x += 1;
          }
          this.sum = x;
          console.error('BS2: block done');
        })
      Text('sum=' + this.sum)
        .fontSize(12)
    }
    .width('100%')
    .height('100%')
    .alignItems(HorizontalAlign.Center)
  }
}
