// B-S7 卡顿·重复行循环验证页
// 场景：高频 touch 事件 + 每 move 事件触发状态更新重渲染，
// 使 ProcessPointerEvent 在日志中同 ms 高频重复（bench 期望：同 ts 重复 30+ 行）。
// 验证方式：页面启动后用 adb input swipe 高频滑动触发。
// 预期 skill 维度④：标"循环嫌疑"（事件处理重复行），处置=查事件分发循环/重入。

@Component
struct TouchPad {
  build() {
    Column()
      .width('100%')
      .height('100%')
      .backgroundColor('#EEF')
  }
}

@Entry
@Component
struct Index {
  @State moveCount: number = 0;

  build() {
    Column() {
      Text('B-S7 loop: touch event storm')
        .fontSize(12)
        .margin({ top: 8 })
      Text('moves: ' + this.moveCount)
        .fontSize(12)
      TouchPad()
        .layoutWeight(1)
        .width('100%')
        .onTouch((event: TouchEvent) => {
          if (event.type === TouchType.Move) {
            // 每次 move 都更新状态 -> 触发重渲染 -> 事件-渲染循环压力
            this.moveCount += 1;
          }
        })
    }
    .width('100%')
    .height('100%')
  }
}
