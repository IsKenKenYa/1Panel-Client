# UI Dump 可视化（ArkUI / OpenHarmony UI Tree Visualizer）

把 ArkUI / OpenHarmony inspector 导出的 **UI 组件树 dump** 解析成一个
**自包含、可交互的 HTML**：用 SVG 圆形节点画出组件树骨架与父子关系，按节点状态着色，
叠加内存信息，并对上万节点的超大树自动做「骨架 + 聚合」精简。

- 纯 **Node.js + TypeScript** 流水线，**零第三方依赖**（不联网、不打包）。
- 产物是单个 `dumps_result_<日期>/index.html`，数据已内联，**离线双击即可打开**。

---

## 功能特性

### 树视图（默认）
- **圆形节点 + 紧凑布局**：自上而下，Reingold–Tilford 轮廓排布，同层子树紧贴、少留白。
- **按状态着色**（节点填充色 = 状态）：
  - 🟢 在树显示　🟠 在树隐藏　⚪️ 游离
- **显示精简**（对所有 dump 生效，数据仍全量加载，只精简显示层）：用「关键容器骨架 + 同级散件聚合」把 7000+ 节点的树压到可读规模。
  - **关键容器**（`root`、`Navigation*`、`Tab*`、`Swiper*`、`Repeat`、`LazyForEach`、`ForEach`）构成骨架，递归展开。
  - 夹在其间的散件就地聚合为子节点：**关键组件**（`Text`/`Image`/`XComponent`/`Web`）按 *(类型 × 状态)*，其余按 *状态*；聚合节点圆内显示数量。
- **内存信息**：每个节点显示 **自身 + 全部子孙** 的总内存（含图形资源），随量级用 kb / MB，并按热度着色；详情/悬停可看自身内存（基础 + 图形）拆分。
- **默认「隐藏态」视图**：自动展开通往每个「在树隐藏」节点的路径、折叠纯「在树显示」分支，便于定位被隐藏组件。
- **游离根开关**：与 root 同层的其它顶层树（游离根）默认隐藏，一键显示。
- 工具栏：`游离根` / `展开` / `隐藏态` / `折叠` / `适应`。

### 通用交互
- **悬停提示**：状态 / ID / 内存 / Frame / 组件名 / 文本内容；聚合节点显示数量 + 内存和。
- **详情面板**：从 root 到该节点的可点击路径、关键字段、**完整原始属性**。
- **搜索**：按 标签 / ID / 文本 / compid / 组件名 过滤，命中高亮并缩放到命中范围。
- **平移 / 缩放 / 适应**，多 dump 数据源下拉切换，浅色主题。

---

## 快速开始

需要 **Node ≥ 23**（直接运行 TypeScript，无需 tsc；本机用 Node 26 验证）。

```bash
# 把 *.dump 放进 dumps/（可按应用建子目录，如 dumps/<app>/xxx.dump）
npm run all          # = 生成内存 CSV + 构建 HTML
```

产物输出到按当天日期命名的目录：`dumps_result_<YYYY-MM-DD>/index.html`；同时维护一个指向当天目录的稳定软链 `dumps_result_latest/`（方便预览/脚本固定引用，无需每天改路径）。

**查看**：直接浏览器打开该 HTML，或起个静态服务：

```bash
python3 -m http.server 8917 --directory dumps_result_latest   # http://localhost:8917（始终是最新一次构建）
```

**其它命令**：

```bash
npm run build        # 只重新构建 HTML（用现有 dumps + memory.csv）
npm run gen-memory   # 只重新生成 database/memory.csv（基础内存）
```

---

## 打包发布

将项目编译并打包为本地 `.tar.gz`，分发给他人安装使用：

```bash
npm run pack         # 编译 + 复制资源 + 生成 arkui-dump-viewer-1.0.0.tar.gz
```

**安装与使用**（收到 `.tar.gz` 的人）：

```bash
npm install -g arkui-dump-viewer-1.0.0.tar.gz

# 目录模式（批量处理）
arkui-dump-viewer ./dumps

# 单文件模式
arkui-dump-viewer xxx.dump

# 可选参数
arkui-dump-viewer ./dumps --csv custom.csv --output ./result
```

---

## 目录结构

```
src/
├─ parser.ts        # dump 文本 → 树（按缩进重建父子；多顶层树 = 森林，挂到合成根）
├─ dump-files.ts    # 递归发现 dumps/ 下的 *.dump（支持子目录分组）
├─ gen-memory.ts    # 生成 database/memory.csv（每个节点的基础内存）
├─ build.ts         # 解析 + join 内存 + 把数据与前端内联进单个 HTML
└─ client/
   ├─ template.html # 页面骨架（含占位符）
   ├─ styles.css    # 样式（浅色主题）
   └─ app.js        # 浏览器端渲染与交互（原生 JS + SVG）
dumps/              # 输入：*.dump（未纳入 git，见 .gitignore）
database/memory.csv # 组件基础内存（组件名,内存kb,）
dumps_result_<日期>/index.html   # 输出：自包含可视化页面
```

---

## 工作原理

### dump 格式与解析
节点头形如 `<缩进>|-> <type>[,id,accessibilityId] childSize:<N>`，**缩进每级 2 个空格**，据此栈式重建父子关系；属性行紧随其后直到下一个节点头（深层节点 dumper 会省略 `|` 前缀，故按结构切分而非依赖 `|`）。解析器抽取 `ID` / `Depth` / `VisibleAndActive` / `ComponentName` / `compid` / `Content` / `FrameRect` / `rawImageSize` 等字段，并保留整段原文供详情面板展示。

```
        |-> Text childSize:0
              ID: 60
              Depth: 23
              VisibleAndActive: 1
              FrameRect: RectT (210.00, 548.00) - [300.00 x 35.00]
              Content: 查看按时间分组的照片
```

### 节点状态（三态）
| 状态 | 判定（只看在哪棵顶层树下，**与 IsOnMainTree 无关**）|
|---|---|
| 在树显示 | 是 `root` 的子孙，且 `VisibleAndActive == 1` |
| 在树隐藏 | 是 `root` 的子孙，且 `VisibleAndActive == 0` |
| 游离 | 不是 `root` 子孙（在某个游离根树下）|

### 组件内存
- **基础内存**：所有组件都有，取自 `database/memory.csv`。
- **图形资源内存**：仅 `Image`（`rawImageSize` 的 `w×h×4` Bytes）、`XComponent`/`Web`（`FrameRect` 的 `w×h×4×5` Bytes）额外叠加。
- 节点展示的是**整棵子树的总内存**（自身 + 全部子孙）。

> 完整的格式规则、状态/关键容器/内存定义与精简算法见
> [`.claude/references/ui-dump-format.md`](.claude/references/ui-dump-format.md)。

---

## 关于工程基座

本仓库基于 **agent-harness-template**（AI 协作基础设施：skill 工作流、归档、pre-commit 一致性校验）。
可视化相关的工作流见 skill [`/visualize-ui-dump`](.claude/skills/visualize-ui-dump.md)；
基座说明见 [`CLAUDE.md`](CLAUDE.md) / [`AGENTS.md`](AGENTS.md)。
